import UIKit

var greeting = "Hello, playground"
var httpError = (errorCode:404,errorMessage:"Page Not Found")
print(httpError)
print(httpError.errorCode,terminator: ":")
print(httpError.errorMessage)

var name=("John","Smith")
var fname=name.0
var lname=name.1
print(fname, terminator:",")
print(lname)
var origin=(x:0,y:0)
var point=origin
print(point)
let city = (name:"Maryville",population:11, 000)
let (cityName,cityPopulation )=(city.0,city.1)
print(cityName)
print(cityPopulation)

let groceries = ("bread", "onions")
print(groceries.0)
print(groceries.1)
print(type(of:groceries))

var fName = "Joe"
var lName = "Root"
(fName,lName)=(lName,fName)
print("First Name is \(fName) and Last Name is \(lName)")

var cricketKit = ("handGloves","helmet",("bat","ball"))
print(cricketKit.0)
print(cricketKit.1)
print(cricketKit.2.0)
print(cricketKit.2.1)
