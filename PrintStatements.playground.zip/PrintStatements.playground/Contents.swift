import UIKit

var greeting = "Hello, playground"
print("Hello World")
print(greeting)

print("Hi",10,12.25)
print("Hello World"+greeting)
print("Hello World\(greeting)")
//variable can be changed
var age=24
//String interpolation
print("I'm are going to be \(age)")
//It doesn't work because concatenation of different datatypes is not allowed
//print("I'm going to be " +age)
print("""
Hello
World!
From Us and i'm \(age)
""")

print("Hello All,\rWelcome to Swift programming")
//When we use let we cannot t=change the value later
let welcomeMessage: String = "Hello!"
print(welcomeMessage, "All")
//welcomeMessage= "Good Bye" cannot change the constants
var name: String = "John"
print(name,2,"Smith")
name="Bob"
print(name)
print("Welcome to Swift programming")
print("Fall 2021")
print("*****************")
print("Welcome to Swift programming", terminator: "-")
print("Fall 2022")
print("The list of numbers are")
print(1,2,3,4,5,6)
print("The new pattern is")
print(1,2,3,4,5,6, separator: "-")
